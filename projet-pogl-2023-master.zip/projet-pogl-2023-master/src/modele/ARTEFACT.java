package modele;

public enum ARTEFACT {
    MOTEUR, HELICE, GOUVERNAIL, CAPTEUR;
}
